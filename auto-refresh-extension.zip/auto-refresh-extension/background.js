// Mapa em memória: tabId -> { seconds, active }
// Também persistimos em chrome.storage.local para sobreviver a reinícios do service worker.

function alarmName(tabId) {
  return `auto-refresh-${tabId}`;
}

async function getAllStates() {
  const data = await chrome.storage.local.get("states");
  return data.states || {};
}

async function saveStates(states) {
  await chrome.storage.local.set({ states });
}

async function startRefresh(tabId, seconds) {
  const states = await getAllStates();
  states[tabId] = { seconds, active: true };
  await saveStates(states);

  // Chrome aplica um mínimo de ~0.5min (30s) para alarmes periódicos em produção.
  const periodInMinutes = Math.max(seconds / 60, 0.5);

  chrome.alarms.clear(alarmName(tabId), () => {
    chrome.alarms.create(alarmName(tabId), {
      periodInMinutes,
    });
  });
}

async function stopRefresh(tabId) {
  const states = await getAllStates();
  if (states[tabId]) {
    states[tabId].active = false;
    await saveStates(states);
  }
  chrome.alarms.clear(alarmName(tabId));
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith("auto-refresh-")) return;
  const tabId = parseInt(alarm.name.replace("auto-refresh-", ""), 10);

  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      // Aba não existe mais: limpa o alarme e o estado.
      chrome.alarms.clear(alarm.name);
      getAllStates().then((states) => {
        delete states[tabId];
        saveStates(states);
      });
      return;
    }
    chrome.tabs.reload(tabId);
  });
});

// Remove o estado quando a aba é fechada.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  chrome.alarms.clear(alarmName(tabId));
  const states = await getAllStates();
  if (states[tabId]) {
    delete states[tabId];
    await saveStates(states);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "START") {
      await startRefresh(message.tabId, message.seconds);
      sendResponse({ ok: true });
    } else if (message.type === "STOP") {
      await stopRefresh(message.tabId);
      sendResponse({ ok: true });
    } else if (message.type === "GET_STATE") {
      const states = await getAllStates();
      const state = states[message.tabId] || { active: false };
      sendResponse(state);
    }
  })();
  return true; // resposta assíncrona
});
