const intervalInput = document.getElementById("interval");
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");

function getCurrentTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      resolve(tabs[0]);
    });
  });
}

async function refreshUI() {
  const tab = await getCurrentTab();
  if (!tab) return;
  chrome.runtime.sendMessage(
    { type: "GET_STATE", tabId: tab.id },
    (state) => {
      if (state && state.active) {
        intervalInput.value = state.seconds;
        statusEl.textContent = `Ativo — atualizando a cada ${state.seconds}s`;
        statusEl.classList.remove("off");
      } else {
        statusEl.textContent = "Desativado nesta aba";
        statusEl.classList.add("off");
      }
    }
  );
}

startBtn.addEventListener("click", async () => {
  const tab = await getCurrentTab();
  const seconds = Math.max(1, parseInt(intervalInput.value, 10) || 30);
  chrome.runtime.sendMessage(
    { type: "START", tabId: tab.id, seconds },
    () => refreshUI()
  );
});

stopBtn.addEventListener("click", async () => {
  const tab = await getCurrentTab();
  chrome.runtime.sendMessage(
    { type: "STOP", tabId: tab.id },
    () => refreshUI()
  );
});

refreshUI();
